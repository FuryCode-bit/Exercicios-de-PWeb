<?php
    echo "<link rel='stylesheet' type='text/css' href='pauta.css'>";

    $xml = file_get_contents('patients.xml');

    $xml_parse = simplexml_load_string($xml);
    //echo "<pre>"; print_r($xml_parse);echo "<pre>";

    echo '<h1>Pacientes </h1>';
    echo '<table>';
    echo '<tr>';
    echo '<th>Identificação</th>';
    echo '<th>Sexo</th>';
    echo '<th>Nome</th>';
    echo '<th>Nascimento</th>';
    echo '<th>BI</th>';
    echo '<th>Contribuinte</th>';
    echo '<th>Sistema de Saúde</th>';
    echo '<th>Médica de Familia</th>';
    echo '</tr>';

    foreach($xml_parse as $k=>$v){
        if($v->birth > 2004){
            echo '<tr>';
            echo '<td> '. $v->id.'</td>';
            echo '<td> '. $v->gender.'</td>';
            echo '<td> '. $v->name.'</td>';
            echo '<td> '. $v->birth.'</td>';
            echo '<td> '. $v->bi.'</td>';
            echo '<td> '. $v->tax.'</td>';
            echo '<td> '. $v->healthsystem.'</td>';
            if(strcmp($v->gender, 'M') == 0) {
                echo '<td>Dr. Marcelo Pereira</td>';
            } else {
                echo '<td>Dra. Josefina Fontes</td>';
            }
            echo '</tr>';
        }
    }
    echo '</table>';
?>